package edu.montana.csci.csci468.parser.expressions;

import edu.montana.csci.csci468.bytecode.ByteCodeGenerator;
import edu.montana.csci.csci468.eval.CatscriptRuntime;
import edu.montana.csci.csci468.parser.CatscriptType;
import edu.montana.csci.csci468.parser.ErrorType;
import edu.montana.csci.csci468.parser.ParseError;
import edu.montana.csci.csci468.parser.SymbolTable;
import edu.montana.csci.csci468.parser.statements.FunctionDefinitionStatement;
import org.objectweb.asm.Opcodes;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class FunctionCallExpression extends Expression {
    private final String name;
    List<Expression> arguments;
    private CatscriptType type;

    public FunctionCallExpression(String functionName, List<Expression> arguments) {
        this.arguments = new LinkedList<>();
        for (Expression value : arguments) {
            this.arguments.add(addChild(value));
        }
        this.name = functionName;
    }

    public List<Expression> getArguments() {
        return arguments;
    }

    public String getName() {
        return name;
    }

    @Override
    public CatscriptType getType() {
        return type;
    }

    @Override
    public void validate(SymbolTable symbolTable) {
        FunctionDefinitionStatement function = symbolTable.getFunction(getName());
        if (function == null) {
            addError(ErrorType.UNKNOWN_NAME);
            type = CatscriptType.OBJECT;
        } else {
            type = function.getType();
            if (arguments.size() != function.getParameterCount()) {
                addError(ErrorType.ARG_MISMATCH);
            } else {
                for (int i = 0; i < arguments.size(); i++) {
                    Expression argument = arguments.get(i);
                    argument.validate(symbolTable);
                    CatscriptType parameterType = function.getParameterType(i);
                    if (!parameterType.isAssignableFrom(argument.getType())) {
                        argument.addError(ErrorType.INCOMPATIBLE_TYPES);
                    }
                }
            }
        }
    }

    //==============================================================
    // Implementation
    //==============================================================

    @Override
    public Object evaluate(CatscriptRuntime runtime) {
        // Evaluate all our arguments to build up a list of parameters
        List<Object> parameterValues = new ArrayList<>();
        for (Expression argument : arguments) {
            parameterValues.add(argument.evaluate(runtime));
        }
        // Retrieve the function definition from  the runtime or symbol table
        FunctionDefinitionStatement function = getProgram().getFunction(name);
        if (function == null) {
            throw new RuntimeException("Function " + name + " is not defined");
        }
        // Invoke the function with the evaluated arguments and return the result
        Object yo =  function.invoke(runtime, parameterValues);
        if (yo != null){
            return yo;
        } else {
            return null;
        }
    }

    @Override
    public void transpile(StringBuilder javascript) {
        super.transpile(javascript);
    }

    @Override
    public void compile(ByteCodeGenerator code) {
        //Load this 'this' pointer.
        code.addVarInstruction(Opcodes.ALOAD, 0);
        FunctionDefinitionStatement funcdefsta = getProgram().getFunction(name);
        //Iterate over all the params and compile them.
        for(int i =0; i < getArguments().size(); i++){
            //If the param type is an object, than box.
            Expression e = arguments.get(i);
            if(funcdefsta.getParameterType(i).equals(CatscriptType.OBJECT)&&(e.getType().equals(CatscriptType.INT)||e.getType().equals(CatscriptType.BOOLEAN))){
                e.compile(code);
                box(code, e.getType());
            }else {
                e.compile(code);
            }
        }
        //Invoke the function:
        if(funcdefsta == null){
            System.out.println("Function is null.");
        }
        code.addMethodInstruction(Opcodes.INVOKEVIRTUAL,
                code.getProgramInternalName(),funcdefsta.getName(),funcdefsta.getDescriptor());
    }


}
